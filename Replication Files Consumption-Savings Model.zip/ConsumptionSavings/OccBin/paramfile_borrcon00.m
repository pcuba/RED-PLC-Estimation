
R    = 1.05;
BETA = 0.945;
RHO  = 0.9;
STD_U= 0.010;
M = 1;
GAMMAC = 1; 


load PARAM_EXTRA_BABY