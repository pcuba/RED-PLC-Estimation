function setFigOptions(f)

set(figure(f),'PaperType','usletter','PaperOrientation','landscape','PaperPosition',[0.1 0.1 10.5 8]);

end